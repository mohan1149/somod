<?php
 return [
"stock_adjustment" => "تسوية المخزون",
"stock_adjustments" => "تسويات المخزون",
"list" => "قائمة تسويات المخزون",
"add" => "عمل تسوية للمخزون",
"all_stock_adjustments" => "جميع تسويات المخزون",
"search_product" => "البحث عن المنتجات",
"adjustment_type" => "نوع الضبط",
"normal" => "عادي",
"abnormal" => "غير عادي",
"total_amount" => "المبلغ الإجمالي",
"total_amount_recovered" => "المبلغ الإجمالي المسترد",
"reason_for_stock_adjustment" => "السبب",
"stock_adjustment_added_successfully" => "تمت إضافة تسوية المخزون بنجاح",
"search_products" => "البحث عن المنتجات",
"delete_success" => "تم حذف تسوية المخزون بنجاح",
"view_details" => "عرض تفاصيل تسوية المخزون",
];

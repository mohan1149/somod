<?php
 return [
"categories" => "الاقسام",
"manage_your_categories" => "إدارة الأقسام الخاصة بك",
"all_your_categories" => "كل اقسامك",
"category" => "القسم",
"category_name" => "إسم القسم",
"code" => "رمز القسم",
"add_as_sub_category" => "إضافة إلى القسم الفرعي",
"select_parent_category" => "حدد القسم الرئيسي",
"added_success" => "تمت إضافة القسم بنجاح",
"updated_success" => "تم تحديث القسم بنجاح",
"deleted_success" => "تم حذف القسم بنجاح",
"add_category" => "إضافة قسم",
"edit_category" => "تعديل القسم",
];
